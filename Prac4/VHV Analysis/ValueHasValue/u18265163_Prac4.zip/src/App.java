public class App {
    public static void main(String[] args) throws Exception {
        ValueAnalysis valueAnalysis = new ValueAnalysis();
        valueAnalysis.Analyse();
    }
}
