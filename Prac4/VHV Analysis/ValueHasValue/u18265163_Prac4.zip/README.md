-To run the Prac4.jar file, run the following command on the terminal:
"java -jar Prac4.jar" 

*Note: It will not run when clicked

I am using my p2 for this practical so after execution do the following:
-During runtime, you will recieve a prompt to enter a filename(the SPL. You should add this file to the folder) with a .txt extension, type the filename with no trailing spaces and observe the terminal for any sementic errors then open the 'symboltable.html' file for the Symbol Table.

*Table note: The scopeIDs of children procs are related to he nodeIDs of thier parent procs