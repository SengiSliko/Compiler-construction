import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import java.io.*;

class Translate {
    public static void main(String[] args) {
       Translate translate = new Translate();
        try {
            translate.TranslateCode();
        } catch (IOException e) {
            e.printStackTrace();
        }
    
    }

    int currentLine = 10;
   
    private FileWriter fileWriter;
    

    private void TranslateCode() throws IOException {
        fileWriter = new FileWriter("BASIC.bas");
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse("AST.xml");
            Node root = document.getDocumentElement();
            Traverse(root);
            fileWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Traverse(Node node) throws IOException{
        if(node.getNodeType() == Node.ELEMENT_NODE){
            
            if(node.getNodeName().equals("INPUT")){
                String variable = "";
                NodeList children = node.getChildNodes();
                for(int i = 0; i < children.getLength(); i++){
                    Node child = children.item(i);
                    if(child.getNodeType() == Node.ELEMENT_NODE){
                        if(child.getNodeName().equals("NUMVAR")){
                            variable = child.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                        }
                    }
                }

                fileWriter.write(currentLine+ " INPUT \"\";" + variable + "\n");
                currentLine += 10;
            }
            else if(node.getNodeName().equals("OUTPUT")){
                String variable = "";
                NodeList children = node.getChildNodes();
                for(int i = 0; i < children.getLength(); i++){
                    Node child = children.item(i);
                    if(child.getNodeType() == Node.ELEMENT_NODE){
                        if(child.getNodeName().equals("TEXT")){
                           NodeList textChildren = child.getChildNodes();
                            for(int j = 0; j < textChildren.getLength(); j++){
                                 Node textChild = textChildren.item(j);
                                 if(textChild.getNodeType() == Node.ELEMENT_NODE){
                                      if(textChild.getNodeName().equals("STRINGV")){
                                        variable = textChild.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                                      }
                                 }
                            }
                            fileWriter.write(currentLine+ " PRINT ;" + variable +"$" + "\n");
                            currentLine += 10;
                        }
                        else{
                            NodeList textChildren = child.getChildNodes();
                            for(int j = 0; j < textChildren.getLength(); j++){
                                 Node textChild = textChildren.item(j);
                                 if(textChild.getNodeType() == Node.ELEMENT_NODE){
                                      if(textChild.getNodeName().equals("NUMVAR")){
                                        variable = textChild.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                                      }
                                 }
                            }
                            fileWriter.write(currentLine+ " PRINT ;" + variable + "\n");
                            currentLine += 10;
                        }
                    }
                }

            }
            else if(node.getNodeName().equals("ASSIGN")){
                NodeList children = node.getChildNodes();
                String lhs = "";
                String rhs = "";
                for(int j = 0; j < children.getLength(); j++){
                    Node textChild = children.item(j);
                    if(textChild.getNodeType() == Node.ELEMENT_NODE){
                         if(textChild.getNodeName().equals("NUMVAR")){
                           lhs = textChild.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                           for(int i = 0 ; i< children.getLength() ; i++){
                                Node child = children.item(i);
                                if(child.getNodeType() == Node.ELEMENT_NODE){
                                    if(child.getNodeName().equals("NUMEXPR")){
                                        rhs = NumExpr(child);
                                    }
                                }
                           }
                         }
                         else if(textChild.getNodeName().equals("BOOLVAR")){
                            lhs = textChild.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                            for(int i = 0 ; i< children.getLength() ; i++){
                                Node child = children.item(i);
                                if(child.getNodeType() == Node.ELEMENT_NODE){
                                    if(child.getNodeName().equals("BOOLEXPR")){
                                        rhs = BoolExpr(child);
                                    }
                                }
                           }
                         }
                         else if(textChild.getNodeName().equals("STRINGV")){
                            lhs = textChild.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                         }
                    }
                    
               }

                fileWriter.write(currentLine+ " LET " + lhs + " = " + rhs + "\n");
            }   
        }

        if(node.hasChildNodes()){
            NodeList children = node.getChildNodes();
            for(int i = 0; i < children.getLength(); i++){
                Traverse(children.item(i));
            }
        }
    }

    private String NumExpr(Node node){
        NodeList children = node.getChildNodes();
        String textContent = node.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
        for(int i = 0; i < children.getLength(); i++){
            Node child = children.item(i);
            if(child.getNodeType() == Node.ELEMENT_NODE){
                if(child.getNodeName().equals("NUMVAR")){
                    return child.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                }
                else if(child.getNodeName().equals("DECNUM")){
                    return child.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                }
            }
        }
        return "";
    }

    private String BoolExpr(Node node){
        NodeList children = node.getChildNodes();
        String textContent = node.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
        if(textContent.charAt(0) == 'T'){
            return "1";
        }
        else if(textContent.charAt(0) == 'F'){
            return "0";
        }
        for(int i = 0; i < children.getLength(); i++){
            Node child = children.item(i);
            if(child.getNodeType() == Node.ELEMENT_NODE){
                if(child.getNodeName().equals("BOOLVAR")){
                    return child.getTextContent().replace("\n", "").replace("\s", "").replace("\t", "");
                }
            }
        }

        return "";
    }
}