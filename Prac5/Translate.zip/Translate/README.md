Run the executable using the following:
"java -jar Translate.jar"

I am using XML input so you will need to update the AST.xml file to test.