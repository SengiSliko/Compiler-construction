-To run the Translation.jar file, run the following command on the terminal:
"java -jar Translation.jar" 

*Note: It will not run when clicked

I am using my p2 for this practical so after execution do the following:
-During runtime, you will recieve a prompt to enter a filename(the SPL. You should add this file to the folder) with a .txt extension, type the filename with no trailing spaces and open the BASIC.txt file for the target code.