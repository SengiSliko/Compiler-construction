To run the Prac1.jar file on an ubuntu system run the followinf command on the terminal:
"java -jar Prac1.jar"

*Note: It will not run when clicked