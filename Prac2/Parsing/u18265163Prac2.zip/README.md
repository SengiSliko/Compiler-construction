-To run the Prac2.jar file, run the following command on the terminal:
"java -jar Prac2.jar" 

*Note: It will not run when clicked

-During runtime, you will recieve a prompt to enter a filename with a .txt extension, type the filename with no trailing spaces and observe the terminal for errors or the 
'AST.xml' file for the AST.

*Note: the xml might have errors if the "<" and ">" symbols are present